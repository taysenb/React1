import React from "react";
import MyParagraph from "./MyParagraph";

const DemoOutput = (props) => {
  console.log("DemoOutput RUNNING");
  return <MyParagraph>{props.show ? "This is new!" : ""}</MyParagraph>;
};

export default React.memo(DemoOutput);
//memo checks new value of all Demooutput props
//and only if props change will it re-execute Demooutput
// rewatch short video 158 if confused
