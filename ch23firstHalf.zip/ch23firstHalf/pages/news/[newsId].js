import { useRouter } from "next/router"; //hook built in nextjs

// our-domain.com/news/something-important
//[] <<around file name means it will load this page if its any name news/

function DetailPage() {
  const router = useRouter();

  const newId = router.query.newsId;

  //send a request to the backend api
  //to fetch the news item with newsId
  return <h1>The Detail Page</h1>;
}

export default DetailPage;
