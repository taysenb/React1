import { Route, Switch, Redirect } from "react-router-dom";

import Welcome from "./pages/Welcome";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetails";
import MainHeader from "./components/MainHeader";

function App() {
  return (
    <div>
      <MainHeader />
      <main>
        <Switch>
          {/* if nothing is passed to this route it resorts to Redirect */}
          <Route path="/" exact>
            <Redirect to="/welcome" />
          </Route>
          {/* if the url has /welcome in it then this route becomes active */}
          <Route path="/welcome">
            <Welcome />
          </Route>
          <Route path="/products" exact>
            <Products />
          </Route>
          {/*:productId is like a parameter for a function */}
          <Route path="/product/:productId">
            <ProductDetail />
          </Route>
        </Switch>
      </main>
    </div>
  ); //<welcome> is only displayed if url has /welcome
}

export default App;

// our-domain.com/welcome => loads welcome component
// our-domain.com/products => loads products component
