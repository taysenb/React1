//primitives: number, string, boolean
//More complex types: arrays, objects
//Function types, parameters

//Primitives

let age: number;

age = 12;

let userName: string;

userName = "Max";

let isInstructor: boolean;

isInstructor = true;

//more complex types

let hobbies: string[];

hobbies = ["Sports", "Cooking"];

type Person = {
  name: string;
  age: number;
};
//type is built into typescript

let person: Person;

person = {
  name: "Max",
  age: 32,
};

// person = {
//   isEmployee: true,
// };

let people: Person[];
//the [] turns people into an array

//Type inference

let course: string | number = "React - The complete Guide";
//^^ string | number allowes var to be either type
course = 12341;

// Function & types

function add(a: number, b: number) {
  return a + b;
}

function print(value: any) {
  console.log(value);
}

//Generics
//makes types type safe & more flexible          v
function insertAtBeginning<T>(array: T[], value: T) {
  const newArray = [value, ...array]; //value is inserted before arr
  return newArray;
}

const demoArray = [1, 2, 3];

const updatedArray = insertAtBeginning(demoArray, -1); //[-1,1,2,3]
const stringArray = insertAtBeginning(["a", "b", "c"], "d");

//updatedArray[0].split('')
