import React, { useContext } from "react";

import TodoItem from "./TodoItem";
import { TodosContext } from "../store/todos-context";
import classes from "./Todos.module.css";
//todo[] means items: will be vv an arr of todo class objects
const Todos: React.FC = () => {
  const todosCtx = useContext(TodosContext);
  //in visualStudio ctrl + click on FC to learn what it is
  return (
    <ul className={classes.todos}>
      {todosCtx.items.map((item) => (
        <TodoItem
          key={item.id}
          text={item.text}
          onRemoveTodo={todosCtx.removeTodo.bind(null, item.id)}
        />
      ))}
    </ul>
  );
};

export default Todos;
