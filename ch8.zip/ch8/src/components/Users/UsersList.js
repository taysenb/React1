//Userslist.js is used for outputting user data
import React from "react";

import Card from "../UI/Card";
import classes from "./UsersList.module.css";

const UsersList = (props) => {
  return (
    //you can only add className type stuff to homade elements if you specify it where its created
    <Card className={classes.users}>
      <ul>
        {props.users.map((user) => (
          // key= is required for every <li> creates an id for users
          <li key={user.id}>
            {user.name} ({user.age} years old)
          </li>
        ))}
      </ul>
    </Card>
  );
};

export default UsersList;
