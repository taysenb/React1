import { useRef, useState } from "react";

import Input from "../../UI/Input";
import classes from "./MealItemForm.module.css";

const MealItemForm = (props) => {
  const [amountIsValid, setAmountIsValid] = useState(true);
  const amountInputRef = useRef();

  const submitHandler = (event) => {
    event.preventDefault();

    const enteredAmount = amountInputRef.current.value;
    const enteredAmountNumber = +enteredAmount; //converts enteredAmount to number

    if (
      enteredAmount.trim().length === 0 ||
      enteredAmountNumber < 1 ||
      enteredAmountNumber > 5
    ) {
      setAmountIsValid(false);
      return;
    }

    props.onAddToCart(enteredAmountNumber);
  };

  return (
    <form className={classes.form} onSubmit={submitHandler}>
      <Input //ref wont work on these custom components unless you add stuff
        ref={amountInputRef}
        label="Amount"
        input={{
          id: "amount_" + props.id, //dont delete!!
          type: "number",
          min: "1",
          max: "5",
          step: "1",
          defaultValue: "1",
          // ^^this list of props are default and can be used with any html el.
        }}
      />
      <button>+ Add</button>
      {!amountIsValid && <p>Please enter a valid amount (1-5).</p>}
    </form>
  ); //{{}} above is used because we are adding a js element
}; //+ Add is button to add item to cart

export default MealItemForm;
