import React from "react";

import classes from "./Input.module.css";

//ref on line below is from <Input> inside Mealitemform.js
const Input = React.forwardRef((props, ref) => {
  return (
    <div className={classes.Input}>
      <label htmlFor={props.input.id}>{props.label}</label>
      <input ref={ref} {...props.input} />
    </div>
  ); // ...props.input above ensures all key value pairs are added
});

export default Input;
