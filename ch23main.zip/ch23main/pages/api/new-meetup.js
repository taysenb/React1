import { MongoClient } from "mongodb";

// /api/new-meetup
// POST /api/new-meetup

//vv req deals with incoming requests, res deals with sending response
async function handler(req, res) {
  if (req.method === "POST") {
    const data = req.body;
    //vv expected vars coming from req.body
    const { title, image, address, description } = data;

    const client = MongoClient.connect(
      "mongodb+srv://taysen:mac11uzy@cluster0.yxodpnb.mongodb.net/meetups?retryWrites=true&w=majority"
    ); //never run this code on the client side exposes password
    const db = client.db();

    const meetupsCollection = db.collection("meetups");
    //insertOne() inserts one new doc into query
    const result = await meetupsCollection.insertOne(data);

    console.log(result);

    client.close();
    //vv runs 201 status code
    res.status(201).json({ message: "Meetup inserted" });
  }
}

export default handler;
